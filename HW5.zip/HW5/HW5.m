close
clear
clc

c = 299792458 %m/s


[eph,alpha,beta,dow] = read_rinexn('brdc2920.19n');
[obs,t,gps,apr,hant] = read_rinexo('opmt2920.19o');

a_f0 = eph(19);
a_f1 = eph(20);
a_f2 = eph(2);
t_oe = eph(18);


t_sec(:,1) = t(:,4)*3600 + t(:,5)*60 + t(:,6);
delta = a_f0 +a_f1*(t_sec - t_oe)+a_f2*(t_sec - t_oe).^2

sat =[1:3,5:31];

for i = 1:2880;
    

        if sum(~isnan(obs.C1(i,:))) > 4

            j = ~isnan(obs.C1(i,:)) ; 

            C1 = obs.C1(i,j);
            PRN = sat(j);
            for k = 1:length(PRN)
            [x(i,PRN(k)), y(i,PRN(k)), z(i,PRN(k))] = get_satposLS(t_sec(i),PRN(k),eph);
            end


            satpos_0 = [];
            satpos_0(1,:) = x(1,:);
            satpos_0(2,:) = y(1,:);
            satpos_0(3,:) = z(1,:);
            

            rho_0 = norm(apr);
            L(:) = 0

            for k = 1:length(PRN)
                L(PRN(k)) = C1(k) - rho_0 + c .* delta(i);
            end

            
            c_vec(1:31) = -c * 10^-9;
            A = [((x(i,:) - apr(1))./rho_0)' , ((y(i,:) - apr(2))/rho_0)' , ((z(i,:) - apr(3))/rho_0)' , c_vec'];
            B(:,i) = pinv(A)*L';
    
            end

end


[llr(1,:),llr(2,:),llr(3,:)] = xyz2wgs(B(1,:),B(2,:),B(3,:));

llr_rad = llr.* ((pi)/180)
%lambda phi = long lat

for h = 1:2880
R = [-sin(llr_rad(1,h)).*cos(llr_rad(2,h)),-sin(llr_rad(1,h)).*sin(llr_rad(2,h)),cos(llr_rad(1,h)); ...
    -sin(llr_rad(2,h)),cos(llr_rad(2,h)),0.*(llr_rad(2,h)); ...
    cos(llr_rad(1,h)).*cos(llr_rad(2,h)),cos(llr_rad(1,h)).*sin(llr_rad(2,h)),sin(llr_rad(2,h))] ;

ENU(1:3,h) = llr_rad(:,h)' * R ;
end



 VDOP = cov(ENU(3));
 HDOP = sqrt(cov(ENU(2)^2 + cov(ENU(1))^2));
 PDOP = sqrt(cov(ENU(2)^2 + cov(ENU(1))^2 + cov(ENU(3))^2));
 TDOP = cov(t_sec);
 GDOP = sqrt(cov(ENU(2)^2 + cov(ENU(1))^2 + cov(ENU(3))^2 + cov(t_sec)^2 ));

 dop = [VDOP HDOP PDOP TDOP GDOP];

 t_oe
 ENU




 





