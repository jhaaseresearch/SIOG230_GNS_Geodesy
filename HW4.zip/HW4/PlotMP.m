close
clear
clc

% f1 = 1.57542 × 109 Hz
% f2 = 1.2276 × 109 Hz
% c = 0.299792458 × 109 m/s λ1 = c/f1
% λ2 = c/f2



sat = 2

f1 = 1.57542 *10^9 %Hz
f2 = 1.2276 *10^9 %Hz
c = 0.299792458 *10^9 %m/s
lambda1 = c/f1
lambda2 = c/f2

alpha = (f1/f2)^2


[obs,t,gps,apr,hant] = read_rinexo('opmt2910.19o')



L1 = (obs.L1(:,9));
L2 = (obs.L2(:,9)); 
P1 = (obs.P1(:,9));
P2 = (obs.P2(:,9));





MP1_c =  P1-((2/(alpha-1)) +1).*(lambda1.*(L1)) + (2/(alpha-1)).*(lambda2.*(L2));

MP2_c =  P2-((2*alpha/(alpha-1)) +1).*(lambda1.*(L1)) + (2*alpha/(alpha-1)).*(lambda2.*(L2));


 MP1 = MP1_c - movmean(MP1_c,10);
 MP2 = MP2_c - movmean(MP2_c,10);

hours = [1:length(MP1)]* 0.00833333


plot(hours,MP1);

hold on

plot(hours,MP2);

title('MP error of PRN10','FontSize',28);
xlabel('Hours','FontSize',20);
ylabel('MP error(m)','FontSize',20);
ylim([-3 3]);
legend('MP1','MP2','FontSize',20);